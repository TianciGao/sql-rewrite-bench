# Stack Decision Note

## 当前问题
Stack 当前拿到的是 dumps / substrate，还是已经构成可用的 direct SQL query corpus？

## 当前已知事实
- 当前仓库里的 Stack 相关材料是什么
- 是否包含 query text
- 是否包含 schema / dumps / logs
- 是否已 materialize 出任何 Stack-derived case

## 选项
### Option A
Treat Stack as direct SQL query corpus

### Option B
Treat Stack as realism substrate only

## 当前建议
[只写一个]
- choose Option A
or
- choose Option B

## 理由
- 1
- 2
- 3

## 影响
- 对 long-tail pool 有什么影响
- 对 inventory / target-source snapshot 要怎么写
- 当前是否需要继续 acquisition