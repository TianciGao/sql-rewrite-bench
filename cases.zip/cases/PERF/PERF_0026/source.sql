-- PERF_0026 source query.
-- TPC-H Q22 frozen from ref_data/1/subparam_22.
-- Substitutions: country codes = '19','29','21','25','16','10','14'; :n = -1.

select
    cntrycode,
    count(*) as numcust,
    sum(c_acctbal) as totacctbal
from
    (
        select
            substring(c_phone from 1 for 2) as cntrycode,
            c_acctbal
        from
            customer
        where
            substring(c_phone from 1 for 2) in (
                '19', '29', '21', '25', '16', '10', '14'
            )
            and c_acctbal > (
                select
                    avg(c_acctbal)
                from
                    customer
                where
                    c_acctbal > 0.00
                    and substring(c_phone from 1 for 2) in (
                        '19', '29', '21', '25', '16', '10', '14'
                    )
            )
            and not exists (
                select
                    *
                from
                    orders
                where
                    o_custkey = c_custkey
            )
    ) as custsale
group by
    cntrycode
order by
    cntrycode;
