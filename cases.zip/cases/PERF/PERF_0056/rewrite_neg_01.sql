-- PERF_0056 negative rewrite SQL.
-- Frozen from TPC-DS query_templates/query6.tpl via repaired repo-local dsqgen:
--   COUNT=1, QUALIFY=Y, SCALE=1, DIALECT=ansi
-- PostgreSQL normalization replaces TOP 100 with LIMIT 100.

select a.ca_state state, count(*) cnt
from customer_address a, customer c, store_sales s, date_dim d, item i
where a.ca_address_sk = c.c_current_addr_sk
  and c.c_customer_sk = s.ss_customer_sk
  and s.ss_sold_date_sk = d.d_date_sk
  and s.ss_item_sk = i.i_item_sk
  and d.d_month_seq = (
      select distinct d_month_seq
      from date_dim
      where d_year = 2000
        and d_moy = 2
  )
  and i.i_current_price > 1.2 * (
      select avg(j.i_current_price)
      from item j
      where j.i_category = i.i_category
  )
group by a.ca_state
having count(*) >= 11
order by cnt, a.ca_state
limit 100;
