-- PERF_0051 negative rewrite.
-- Incorrectly changes the prior-year week alignment by one week.

-- Frozen from TPC-DS query_templates/query59.tpl via repaired repo-local dsqgen:
--   COUNT=1, QUALIFY=Y, SCALE=1, DIALECT=ansi
-- PostgreSQL normalization replaces TOP 100 with LIMIT 100 and keeps the standard-template source path.

with wss as (
    select
        d_week_seq,
        ss_store_sk,
        sum(case when d_day_name = 'Sunday' then ss_sales_price else null end) as sun_sales,
        sum(case when d_day_name = 'Monday' then ss_sales_price else null end) as mon_sales,
        sum(case when d_day_name = 'Tuesday' then ss_sales_price else null end) as tue_sales,
        sum(case when d_day_name = 'Wednesday' then ss_sales_price else null end) as wed_sales,
        sum(case when d_day_name = 'Thursday' then ss_sales_price else null end) as thu_sales,
        sum(case when d_day_name = 'Friday' then ss_sales_price else null end) as fri_sales,
        sum(case when d_day_name = 'Saturday' then ss_sales_price else null end) as sat_sales
    from store_sales, date_dim
    where d_date_sk = ss_sold_date_sk
    group by d_week_seq, ss_store_sk
)
select
    s_store_name1,
    s_store_id1,
    d_week_seq1,
    sun_sales1 / sun_sales2,
    mon_sales1 / mon_sales2,
    tue_sales1 / tue_sales2,
    wed_sales1 / wed_sales2,
    thu_sales1 / thu_sales2,
    fri_sales1 / fri_sales2,
    sat_sales1 / sat_sales2
from (
    select
        s_store_name as s_store_name1,
        wss.d_week_seq as d_week_seq1,
        s_store_id as s_store_id1,
        sun_sales as sun_sales1,
        mon_sales as mon_sales1,
        tue_sales as tue_sales1,
        wed_sales as wed_sales1,
        thu_sales as thu_sales1,
        fri_sales as fri_sales1,
        sat_sales as sat_sales1
    from wss, store, date_dim d
    where d.d_week_seq = wss.d_week_seq
      and ss_store_sk = s_store_sk
      and d_month_seq between 1185 and 1185 + 11
) y,
(
    select
        s_store_name as s_store_name2,
        wss.d_week_seq as d_week_seq2,
        s_store_id as s_store_id2,
        sun_sales as sun_sales2,
        mon_sales as mon_sales2,
        tue_sales as tue_sales2,
        wed_sales as wed_sales2,
        thu_sales as thu_sales2,
        fri_sales as fri_sales2,
        sat_sales as sat_sales2
    from wss, store, date_dim d
    where d.d_week_seq = wss.d_week_seq
      and ss_store_sk = s_store_sk
      and d_month_seq between 1185 + 12 and 1185 + 23
) x
where s_store_id1 = s_store_id2
  and d_week_seq1 = d_week_seq2 - 51
order by s_store_name1, s_store_id1, d_week_seq1
limit 100;
